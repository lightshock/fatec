<?php
//Pegar o post
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$message = $_POST['message'];

$con = mysqli_connect("mysql.db5.net2.com.br","lightshock3","facu123","lightshock3");
//if (!$con)
//{die('Could not connect: ' . mysql_error());}
//else
//{echo "Conectado!";}

$query = "INSERT INTO lightshock3.comentario(name, email, phone, message) VALUES ('$name','$email','$phone','$message')";
$insert = mysqli_query($con,$query);

mysqli_close($con);


if($insert){
		echo "<script language='javascript' type='text/javascript'>alert('Mensagem Enviada com Sucesso!');window.location.href='contato.html'</script>";}
	else {
		echo "<script language='javascript' type='text/javascript'>alert('Não foi possivel enviar a mensagem!');window.location.href='contato.html'</script>";
	}

?>